
import streamlit as st
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
import google.generativeai as genai
import os

st.set_page_config(page_title="Persona Adaptive Support Agent")

def detect_persona(text):
    t = text.lower()
    if any(x in t for x in ["api","stack","integration","code","error"]):
        return "Technical Expert"
    if any(x in t for x in ["angry","upset","frustrated","terrible"]):
        return "Frustrated User"
    return "Business Executive"

@st.cache_resource
def build_vectorstore():
    docs = []
    if os.path.exists("data/kb.txt"):
        with open("data/kb.txt","r",encoding="utf-8") as f:
            docs = [Document(page_content=f.read())]
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_documents(docs)
    emb = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    return FAISS.from_documents(chunks, emb)

st.title("Persona-Adaptive Customer Support Agent")

api_key = st.sidebar.text_input("Gemini API Key", type="password")

query = st.text_area("Customer Query")

if st.button("Generate") and query:
    persona = detect_persona(query)
    db = build_vectorstore()
    docs = db.similarity_search(query, k=3)
    context = "\n".join([d.page_content for d in docs])

    escalation = any(x in query.lower() for x in ["legal","lawsuit","manager","refund escalation"])

    if api_key:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.5-flash")
        prompt = f'''
        Persona: {persona}
        Context: {context}
        Customer Query: {query}

        Answer in persona style.
        '''
        response = model.generate_content(prompt).text
    else:
        response = "Add Gemini API key."

    st.subheader("Persona")
    st.write(persona)

    st.subheader("Response")
    st.write(response)

    st.subheader("Escalation")
    st.write("Required" if escalation else "Not Required")

    st.subheader("Retrieved Context")
    st.write(context)
